let userName = 'Jenae' // Try edit me

// Update header text
userName === 'Jenae' ? console.log(`Hello ${userName}!`) : console.log('Hello')
Math.floor(Math.random(randomNumber) * 8)
// Log to console
const userQuestion = `${userName}, what exactly is the magic eightball?`
let eightball = '';
let randomNumber = Math.floor(Math.random()* 8);
console.log(userQuestion, randomNumber)
switch (randomNumber) {
  case 0:
  console.log('try again')
  break;
  case 1:
  console.log('yes')
  break;
  case 2:
  console.log('no')
  break;
  case 3:
  console.log('maybe')
  break;
  case 4:
  console.log('I\'d say so')
  break;
  default:
  console.log('ABSOLUTELY')
}
